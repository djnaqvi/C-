/**
 Khadija Naqvi
 
 Description: This is a guessing game. The computer randomly generates a number in between 1 and 100 that the player has to guess. For each guess, the computer informs the player whether the guess was too high or too low. The program then asks the player whether or not they want to play again and if the user says yes, then the game starts over with a new number. If the player says no, the program ends.
 */
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int guess; // Variable for player's guess
char answer; // Variable for player's answer to "play again?"
void Guess(); //Function for guessing the number
void playAgain(); //Function for whether or not the player wants to go again

int main(void) {
    Guess();
    playAgain();
    return 0;
}
void Guess() {
    srand(unsigned(time(NULL))); //Makes sure the random number is different each time the game is played
    int number = rand() % 101; //Variable that stores the random number
    //cout << number << "\n"; //Show the random number for testing purposes
    //For the player to guess
    while(true) {
        cout << "Enter a number between 1 and 100: ";
        cin >> guess;
        cin.ignore();
        //Check if the player's guess is correct
        if(guess > number) {
            cout << "Too high, try again!\n";
        }
        else if(guess < number) {
            cout << "Too low, try again!\n";
        } //If the player's guess is too high or too low, they keep guessing
        else if(guess == number) {
            cout<<"Congratulations, you guessed correctly! " << endl;
            break; //If the player guesses correctly, the loop stops
        }
    }
};
//The player is asked whether they want to play again
void playAgain() {
    cout << "Would you like to play again (Y/N)? ";
    cin >> answer;
    cin.ignore();
    // Check user's input and run again or exit;
    while (answer == 'n' || answer == 'N') {
        break; //If they say no, the program exits
    }
    while (answer == 'y' || answer == 'Y'){
        main(); //If they say yes, the program starts over again
    }
}

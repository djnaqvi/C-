/**
 
 Description: Write a program to implement the algorithm for evaluating postfix expressions that involve only single-digit integers and the integer operations +, -, *, and /. To trace the action of postfix evaluation, display each token as it is encountered, and display the action of each stack operation. 
 */



#include <iostream>
#include <stack>
#include <limits>
#include <string>
using namespace std;

int main(){
    string exp;
    string ch = "Y";
    while(ch[0] == 'Y' || ch[0] == 'y'){
        cout << "Please enter the RPN expression to be evaluated\n(Note: Each digit or operator should be separated by a space, and end with ':'): " << endl;
        getline(cin, exp);
        unsigned int op1, op2, result;
        stack<int>operation;
        
        int i = 0;
        while (i < (exp.length() - 1)){
            //ignore whitespaces
            if (isspace(exp[i])){
            }
            //get multi-digit number
            else if (isdigit(exp[i])){
                int num = 0;
                
                do{
                    num = num * 10 + (exp[i] - '0');
                    i++;
                    if (i >= exp.length()){
                        cout<<"Error occurred"<<endl;
                    }
                } while (isdigit(exp[i]));
                operation.push(num);
                cout << "Token = " << num << " Push "<< num << endl;
            }
            else{
                op2 = operation.top();
                operation.pop();
                op1 = operation.top();
                operation.pop();
                switch(exp[i]){
                    case '+':
                        result=op1 + op2;
                        operation.push(result);
                        break;
                        
                    case '-':
                        result=op1 - op2;
                        operation.push(result);
                        
                        break;
                        
                    case '*':
                        result=op1 * op2;
                        operation.push(result);
                        
                        break;
                    case '/':
                        result=op1 / op2;
                        operation.push(result);
                        
                        break;
                        
                    default:
                        cout << "Erroneous operator" << endl;
                }
                cout << "Token = "<< exp[i] <<" Pop "<< op2 <<" Pop "<<op1<<" Push "<< result << endl;
                
            }
            i++;
        }
        
        while (!operation.empty()){
            operation.pop();
        }
        
        
        cout << "Token = Pop " << result << endl;
        cout << endl;
        cout << "Type 'Y' or 'y' to continue or type any other letter to quit: ";
        getline(cin, ch);
    }
    return 0;
}

/* SAMPLE RUN
 Please enter the RPN expression to be evaluated
 (Note: Each digit or operator should be separated by a space, and end with ':'):
 9 2 1 + / 4 *
 Token = 9 Push 9
 Token = 2 Push 2
 Token = 1 Push 1
 Token = + Pop 1 Pop 2 Push 3
 Token = / Pop 3 Pop 9 Push 3
 Token = 4 Push 4
 Token = Pop 3
 
 Type 'Y' or 'y' to continue or type any other letter to quit: y
 Please enter the RPN expression to be evaluated
 (Note: Each digit or operator should be separated by a space, and end with ':'):
 2 3 4 + *
 Token = 2 Push 2
 Token = 3 Push 3
 Token = 4 Push 4
 Token = + Pop 4 Pop 3 Push 7
 Token = Pop 7
 
 Type 'Y' or 'y' to continue or type any other letter to quit: n
 Program ended with exit code: 0
*/

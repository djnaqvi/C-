/**
 Khadija Naqvi
 */

#include <iostream>
#include <cmath>
using namespace std;

#include "BigInt.h"

//--- Definition of read()
void BigInt::read(istream & in)
{
  static bool instruct = true;
  if (instruct)
  {
     cout << "Enter " << DIGITS_PER_BLOCK << "-digit blocks, separated by "
            "spaces.\nEnter a negative integer in last block to signal "
            "the end of input.\n\n";
    instruct = false;
  }
  short int block;
  const short int MAX_BLOCK = (short) pow(10.0, DIGITS_PER_BLOCK) - 1;
  for (;;)
  {
    in >> block;
    if (block < 0) return;

    if (block > MAX_BLOCK)
      cerr << "Illegal block -- " << block << " -- ignoring\n";
    else
      myList.push_back(block);
  }
}

//--- Definition of display()
void BigInt::display(ostream & out) const
{ 
   int blockCount = 0;
   const int BLOCKS_PER_LINE = 20;   // number of blocks to display per line

   for (list<short int>::const_iterator it = myList.begin(); ; )
   {
      out << setfill('0'); 
      if (blockCount == 0)
         out << setfill(' '); 
 
      if (it == myList.end())
         return;

      out << setw(3) << *it;
      blockCount++ ;

      it++;
      if (it != myList.end())
      {
         out << ',';
         if (blockCount > 0 && blockCount % BLOCKS_PER_LINE == 0)
            out << endl;
      }
   }
}

//--- Definition of operator+()
BigInt BigInt::operator+(BigInt addend2)
{
   BigInt sum;
   short int first,                  // a block of 1st addend (this object)
             second,                 // a block of 2nd addend (addend2)
             result,                 // a block in their sum
             carry = 0;              // the carry in adding two blocks

   list<short int>::reverse_iterator // to iterate right to left
      it1 = myList.rbegin(),         //   through 1st list, and
      it2 = addend2.myList.rbegin(); //   through 2nd list

   while (it1 != myList.rend() || it2 != addend2.myList.rend())
   {
      if (it1 != myList.rend())
      { 
         first = *it1;
         it1++ ;
      }
      else
         first = 0;
      if (it2 != addend2.myList.rend())
      {
         second = *it2;
         it2++ ;
      }
      else
         second = 0;

      short int temp = first + second + carry;
      result = temp % 1000;
      carry = temp / 1000;
      sum.myList.push_front(result);
   }

   if (carry > 0)
      sum.myList.push_front(carry);

   return sum;
}

BigInt BigInt::operator - (BigInt other){ //modified by Khadija Naqvi - overload '-' operator
    if (other> *this)
        return BigInt(0);
    if ((*this).myList == other.myList)
        return BigInt(0);
    BigInt diffBigInt;
    int diff;
    short int ptr1;
    short int ptr2;
    short int borrow = 0;
    
    list<short int>::reverse_iterator itr1 = myList.rbegin();
    list<short int>::reverse_iterator itr2 = other.myList.rbegin();
    
    while(itr1 != myList.rend() || itr2 != other.myList.rend()){
        if (itr1 != myList.rend()){
            ptr1 = *itr1;
            itr1++;
        }
        else{
            ptr1 = 0;
        }
        if (itr2 != other.myList.rend()){
            ptr2 = *itr2;
            itr2++;
        }
        else{
            ptr2 = 0;
        }
        
        diff = ptr1 - ptr2 -borrow;
        
        if (diff < 0){
            diff += MODULUS;
            borrow = 1;
        }
        else{
            borrow = 0;
        }
        diffBigInt.myList.push_front(diff);
    }
    while (diffBigInt.myList.front() == 0)
        diffBigInt.myList.erase(diffBigInt.myList.begin());
    
    return diffBigInt;
}

BigInt BigInt::operator * (BigInt other){ //modified by Khadija Naqvi - overload '*' operator
     BigInt zeroBigint = BigInt(0);
    if ((*this).myList == zeroBigint.myList || other.myList == zeroBigint.myList)
        return zeroBigint;
        
    BigInt pdtBigInt;
    BigInt tBigInt1;
    BigInt tBigInt2;
    unsigned temporary;
    short int ptr1;
    short int ptr2;
    short int product;
    short int carry = 0;
    
    list<short int>::reverse_iterator itr1;
    list<short int>::reverse_iterator itr2;
    for(itr2 = other.myList.rbegin(); itr2!= other.myList.rend(); itr2++){
        carry = 0;
        ptr2 = *itr2;
        tBigInt2 = tBigInt1;
        for (itr1 = myList.rbegin(); itr1 != myList.rend(); itr1++){
        ptr1 = *itr1;
        temporary = ptr1 * ptr2 + carry;
        
        product = temporary % MODULUS;
        carry = temporary / MODULUS;
        tBigInt2.myList.push_front(product);
    }
    if (carry >0){
        tBigInt2.myList.push_front(carry);
    }
    pdtBigInt = pdtBigInt + tBigInt2;
    tBigInt1.myList.push_back(0);
    
    }
    return pdtBigInt;
}


/* SAMPLE RUN:
 Enter a big integer:
 Enter 3-digit blocks, separated by spaces.
 Enter a negative integer in last block to signal the end of input.
 
 347 965 434 213 -1
 Enter another big integer:
 298 432 678 984 -1
 The sum of
	347,965,434,213 + 298,432,678,984
 is
	646,398,113,197
 
 The bigger number of
	347,965,434,213
 and
	298,432,678,984
 is
	347,965,434,213
 
 The subtraction of
	347,965,434,213 - 298,432,678,984
 is
 49,532,755,229
 
 BONUS part:
 The multiplication of
	347,965,434,213 * 298,432,678,984
 is
	103,844,256,726,016,399,679,592
 
 Add more integers (Y or N)? Y
 Enter a big integer:
 453 213 345 -1
 Enter another big integer:
 892 -1
 The sum of
	453,213,345 + 892
 is
	453,214,237
 
 The bigger number of
	453,213,345
 and
	892
 is
	453,213,345
 
 The subtraction of
	453,213,345 - 892
 is
	453,212,453
 
 BONUS part:
 The multiplication of
	453,213,345 * 892
 is
	404,266,303,740
 
 Add more integers (Y or N)? N
 Program ended with exit code: 0
 */

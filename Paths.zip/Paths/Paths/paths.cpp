/**
 Khadija Naqvi
 
 Description: Write a program that must use a recursive function to count the number of northeast paths from one point to another in a rectangular grid. Your program should prompt user to input the numbers of points to north and to east respectively, and then output the total number of paths.
 */

#include<iostream>
#include "timer.h"
using namespace std;

int path(int x1, int y1, int x2, int y2){
    int pTotal = 0;
    if (x1 == x2 && y1 == y2){
        return 1;
    }
    if (x1 != x2){
        pTotal += path(x1 + 1, y1, x2, y2);
    }
    if (y1 != y2){
        pTotal += path(x1, y1 + 1, x2, y2);
    }
    return pTotal;
}

int main(){
    int north, east;
    char input = 'y';
    
    Timer t;
    
    while (input == 'Y' || input == 'y'){
        cout << "How many points north of A is B? ";
        cin >> north;
        cout << "How many points east of A is B? ";
        cin >> east;
        cout << "There are ";
        
        t.start();
        cout << path(0, 0, north, east);
        t.stop();
        
        cout << " northeast paths between A and B." << endl;
        cout << "Process Timer" << endl;
        cout << "----------------------------" << endl;
        cout << "Elapsed Time : ";
        t.show();
        cout << endl << "Enter y or Y to continue next example or any other letter to exit: ";
        cin >> input;
    }
    system("PAUSE");
    
    return 0;
}

/* SAMPLE RUN:

 How many points north of A is B? 2
 How many points east of A is B? 3
 There are 10 northeast paths between A and B.
 Process Timer
 ----------------------------
 Elapsed Time :   Process Timer
 -------------------------------
 User CPU Time  : 0 s
 System CPU Time: 0 s
 Wait Time      : 0.001 s
 -------------------------------
 Elapsed Time   : 0.001 s
 
 
 Enter y or Y to continue next example or any other letter to exit: y
 How many points north of A is B? 12
 How many points east of A is B? 14
 There are 9657700 northeast paths between A and B.
 Process Timer
 ----------------------------
 Elapsed Time :   Process Timer
 -------------------------------
 User CPU Time  : 0.25 s
 System CPU Time: 0 s
 Wait Time      : 0 s
 -------------------------------
 Elapsed Time   : 0.25 s
 
 
 Enter y or Y to continue next example or any other letter to exit: y
 How many points north of A is B? 16
 How many points east of A is B? 16
 There are 601080390 northeast paths between A and B.
 Process Timer
 ----------------------------
 Elapsed Time :   Process Timer
 -------------------------------
 User CPU Time  : 15.45 s
 System CPU Time: 0.06 s
 Wait Time      : 0.06 s
 -------------------------------
 Elapsed Time   : 15.57 s
 
 
 Enter y or Y to continue next example or any other letter to exit: n
 sh: PAUSE: command not found
 Program ended with exit code: 0
*/
